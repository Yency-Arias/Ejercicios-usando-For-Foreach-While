﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //TAREA WHILE DO-WHILE FOR FOREACH
            //YENCY ELADIO ARIAS MARCELINO 2025-0193


            //1.CONTADOR SIMPLE (FOR)
            
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }
            


            //2.SUMA DE NUMEROS (WHILE)
            /*
            int i = 1;
            int suma = 0;

            while (i <= 100)
            {
                suma += i;
                i++;
            }

            Console.WriteLine($"La suma es: {suma}");
            */


            //3.TABLA DE MULTIPLICAR (FOR)
            /*
            Console.WriteLine("Ingresa un numero:");
            int num = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"{num} x {i} = {num * i}");
            }
            */


            //4.NUMEROS PARES (FOR)
            /*
            for (int i = 1; i <= 50; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine(i);
                }
            }
            */


            //5.PROMEDIO DE NOTAS (FOR)
            /*
            Console.WriteLine("Cuantas notas vas a ingresar?");
            int cantidad = Convert.ToInt32(Console.ReadLine());

            double sumaNotas = 0;

            for (int i = 1; i <= cantidad; i++)
            {
                Console.WriteLine($"Ingresa la nota {i}:");
                double nota = Convert.ToDouble(Console.ReadLine());
                sumaNotas += nota;
            }

            double promedio = sumaNotas / cantidad;
            Console.WriteLine($"Promedio: {promedio}");
            */


            //6.ARREGLO DE NUMEROS (FOR)
            /*
            int[] numeros = new int[5];

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine($"Ingresa el numero {i + 1}:");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("Numeros ingresados:");

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine(numeros[i]);
            }
            */


            //7.MAYOR Y MENOR EN ARREGLO (FOR)
            /*
            int[] numeros = new int[10];

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Ingresa el numero {i + 1}:");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }

            int mayor = numeros[0];
            int menor = numeros[0];

            for (int i = 1; i < 10; i++)
            {
                if (numeros[i] > mayor)
                    mayor = numeros[i];

                if (numeros[i] < menor)
                    menor = numeros[i];
            }

            Console.WriteLine($"Mayor: {mayor}");
            Console.WriteLine($"Menor: {menor}");
            */


            //8.CONTADOR POSITIVOS, NEGATIVOS Y CEROS (WHILE)
            /*
            Console.WriteLine("Cuantos numeros vas a ingresar?");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] numeros = new int[n];

            int i = 0;
            int positivos = 0, negativos = 0, ceros = 0;

            while (i < n)
            {
                Console.WriteLine($"Ingresa el numero {i + 1}:");
                numeros[i] = Convert.ToInt32(Console.ReadLine());

                if (numeros[i] > 0)
                    positivos++;
                else if (numeros[i] < 0)
                    negativos++;
                else
                    ceros++;

                i++;
            }

            Console.WriteLine($"Positivos: {positivos}");
            Console.WriteLine($"Negativos: {negativos}");
            Console.WriteLine($"Ceros: {ceros}");
            */


            //9.BUSQUEDA EN ARREGLO (FOREACH)
            /*
            int[] numeros = { 10, 20, 30, 40, 50 };

            Console.WriteLine("Ingresa el numero a buscar:");
            int buscar = Convert.ToInt32(Console.ReadLine());

            int posicion = 0;
            bool encontrado = false;

            foreach (int n in numeros)
            {
                if (n == buscar)
                {
                    Console.WriteLine($"Encontrado en posicion {posicion}");
                    encontrado = true;
                }
                posicion++;
            }

            if (!encontrado)
            {
                Console.WriteLine("No encontrado");
            }
            */


            //10.FRECUENCIA DE VALORES (FOR)
            /*
            Console.WriteLine("Cuantos numeros vas a ingresar?");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] numeros = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Ingresa el numero {i + 1}:");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < n; i++)
            {
                int contador = 0;

                for (int j = 0; j < n; j++)
                {
                    if (numeros[i] == numeros[j])
                    {
                        contador++;
                    }
                }

                Console.WriteLine($"El numero {numeros[i]} se repite {contador} veces");
            }
            */

        }
    }
}